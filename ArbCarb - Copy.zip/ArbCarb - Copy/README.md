# ArbCarb
# ArbCarb
My name is Jason Williams Im a IT professional I've worked for companies like ATT, TransCore and MGQ Telecommunications (via Seminole Hard Rock Casino) to name a few.
Ive gained over 8 years of in field experience in telecommunications and also gained an education from local schools in the Broward County / Miami Dade area.
Learned a complete education at Florida Career College in Fort Lauderdale and Ive been an IT enthusiast since my youth of 7 years old adding controller cards to my Macro ATX motherboard.
I started learning IT and Tech in the earlier ages of life commiting my self to certificate learning starting with my A+ and N+ certifiactes at Beacon Institute in Fort Lauderdale Florida.
I wanted to start this project as a way to merge the sensibility of improvisation and my collective experience of attempts in improving this world by applying my time and studies.
I would like to share with the community just the Idea of my concepts and not the entirety of the code but enough to express the simple Domain Layer and Business Layer of its architecture.
I have some private ideas of what I would like to do with this code, and later software, that I'd like to keep as rights reserved. But for the most part I want to share the basics of the Idea and If need be
or requested the actual implimentation of this code when it can be launched tested. Im working some Non-Profit that would at the larger extent probrably use some of these services of whom id keep privacy to
what the main mission statement will be but upon unvailing ill share more information with you about how to read the full plan that would be sought after by the invested offices. 
This is a Use Case application of code and in no intention is it for me or anyone else to feel that in good merit its to be considered as anything less that providing automation for assisting society
as a whole when in any itteration of and thus in its completion as a service. This is figuratively a great idea that im looking to scale in many ways then one and a true attempt to Automate help to the community while using a social medium that many have overlooked or felt to keep to thier own self unbeknownst of how providing insite and attentions to social mediums in a basic and productive way could shape a change in our society for the better. I would love to hear the insite of others about what they think about the idea but please dont share with me anything that would lead to you thinking that I would want to misuse what every you chose to inform me of. In particular If you want to be apart of this project and have some form of credit please email me@ CreatorsHands358@gmail.com. And in all Honesty im just trying to make a tool of what I know is a habitual necessity in an ever changing society and take my well earned collective knowledge and build with what I know I'm capable of. 

In retrospect, I want to thank AT&T for the opportunity they shared with me and the fact that they actually showed me the most valuable thing about Technology in the lessons of improvisation I felt when given a timeline to fix the problem that I had to make in the first place. In this foresite of my inexperience of connecting people I measured the planch twice or thrice before Id even think about cutting it.

Thanks for all the support from my comrades and I don't know how long this will take to build in full but honestly its something the world needs and something I'd stay commited in building as a service to the
people. Francos say "Se La Vie" and Carribeans say "Wa Gwan" but ILL say "Lets Go" and i appreciate if your in anybit inspired by the Work.

Would love to add some extra features and scale out this entire project into an extremely real addition into peoples everyday life and as a consistent feature through the services this project will provide.
SO, WE BUILDING!! IF YOUR APART OF THIS PROJECT OR COMMUNITY I'LL BE CREATING A DISCORD. THANKS AGAIN.

Jason Crawford Williams. 10/31/2024

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Ideas to scale coding languages into this project:

Immediate Languages:
.Net ASP
C#
SQL
JS,Html,Css
Angualar

Needed Languages:
SWQL SolarWInds
Python
