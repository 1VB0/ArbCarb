﻿using SQLFundamentals.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


namespace SQLFundamentals.DataAccess.Controllers
{
    public class VideoController
    {                                           //CRUD!!//
        public static int CreateVideo( string title, string description, string filePath, ISQLFundamentalsConfigManager configManager)
        {
            string sqlConnectionString = configManager.SQLFundamentalsConnection;
            int videoId = 0;
            string insertSqlCommand = @"INSERT INTO VIDEOS
                                                   (TITLE,
                                                    DESCRIPTION,
                                                    FILEPATH,)
                                             OUTPUT INSERTED.VIDEOID
                                             VALUES
                                                   (@TITLE,
                                                    @DESCRIPTION,
                                                    @FILEPATH, )";
            using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(insertSqlCommand, sqlConnection))
                {
                    sqlCommand.Parameters.Add(new SqlParameter("@TITLE", title));
                    sqlCommand.Parameters.Add(new SqlParameter("@DESCRIPTION", description));
                    sqlCommand.Parameters.Add(new SqlParameter("@FILEPATH", filePath));
                    

                    sqlCommand.Connection.Open();
                    videoId = (int)sqlCommand.ExecuteScalar();//primary key needed
                    sqlCommand.Connection.Close();
                }
            }
            return videoId;
        }
        //int videoID,int userID, string title, string description, string filePath, string uploadDate
        public static int UpdateVideo(int videoID, string title, string description, string filePath,  ISQLFundamentalsConfigManager configManager)
        {                                                                                                     //look to change this in case of error: VideoId or VideoID//
            string sqlConnectionString = configManager.SQLFundamentalsConnection;
            string updateSqlCommand = @"UPDATE VIDEOS
                                               SET TITLE =        @TITLE,
                                                   DESCRIPTION =  @DESCRIPTION,
                                                   FILEPATH =     @FILEPATH,
                                                   
                                             WHERE VIDEOID =      @VIDEOID";
            using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(updateSqlCommand, sqlConnection))
                {
                    sqlCommand.Parameters.Add(new SqlParameter("@TITLE", title));
                    sqlCommand.Parameters.Add(new SqlParameter("@DESCRIPTION", description));
                    sqlCommand.Parameters.Add(new SqlParameter("@FILEPATH", filePath));
                    sqlCommand.Parameters.Add(new SqlParameter("@VIDEOID"  , videoID)); //Constructor Perameter change videoID//

                    sqlCommand.Connection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlCommand.Connection.Close();
                }
            }
            return videoID;
        }

        public static bool DeleteVideo(int videoID, ISQLFundamentalsConfigManager configManager)
        {
            string sqlConnectionString = configManager.SQLFundamentalsConnection;
            string deleteSqlCommand = @"DELETE FROM VIDEOS WHERE VIDEOID = @VIDEOID";
            using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(deleteSqlCommand, sqlConnection))
                {
                    sqlCommand.Parameters.Add(new SqlParameter("@VIDEOID", videoID));

                    sqlCommand.Connection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlCommand.Connection.Close();
                }
            }
            return true;
        }

        public static List<VideoModel>? GetAllVideos(ISQLFundamentalsConfigManager configManager)
        {
            string sqlConnectionString = configManager.SQLFundamentalsConnection;

            List<VideoModel> videoList = new List<VideoModel>();

            string querySql = "SELECT * FROM VIDEOS ORDER BY VIDEOID DESC";// had to change to VIDEOS NOT (!)VIDEO
            using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(querySql, sqlConnection))
                {
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                    {
                        using (DataTable dataTable = new DataTable())
                        {
                            sqlDataAdapter.Fill(dataTable);

                            foreach (DataRow dataRow in dataTable.Rows)
                            {
                                VideoModel videoModel = new VideoModel();

                                videoModel.Title = dataRow["TITLE"]?.ToString() ?? "";
                                videoModel.Description = dataRow["DESCRIPTION"]?.ToString() ?? "";
                                videoModel.FilePath = dataRow["FILEPATH"]?.ToString() ?? "";
                                videoModel.VideoID = Convert.ToInt32(dataRow["VIDEOID"]);


                                videoList.Add(videoModel);
                            }
                        }
                    }
                }
            }

            return videoList;
        }

        public static VideoModel? GetVideoByID(int videoID, ISQLFundamentalsConfigManager configManager)
        {
            string sqlConnectionString = configManager.SQLFundamentalsConnection;
            VideoModel videos = new VideoModel();

            string querySql = "SELECT * FROM VIDEOS WHERE VIDEOID = @VIDEOID";
            using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(querySql, sqlConnection))
                {
                    sqlCommand.Parameters.Add(new SqlParameter("@VIDEOID", videoID));
                    sqlConnection.Open();
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();

                            videos.VideoID = Convert.ToInt32(reader["VIDEOID"]);
                            videos.Description = reader["DESCRIPTION"]?.ToString() ?? "";
                            videos.FilePath = reader["FILEPATH"]?.ToString() ?? "";
                            videos.Title = reader["TITLE"]?.ToString() ?? "";
                            
                        }
                        else
                        {
                            throw new Exception("No rows found.");
                        }
                    }

                    sqlConnection.Close();
                }
            }
            return videos;// may need to be changed
        }
    }
}