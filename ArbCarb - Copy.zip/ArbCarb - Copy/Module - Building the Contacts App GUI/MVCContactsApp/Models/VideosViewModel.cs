﻿using SQLFundamentals.DataAccess;
using SQLFundamentals.DataAccess.Models;
using SQLFundamentals.DataAccess.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace MVCContactsApp.Models
{    //GetAllVideo GetVideo
    public class VideosViewModel
    {
        private ISQLFundamentalsConfigManager _configuration;

        public List<VideoModel> VideoList { get; set; }

        public VideoModel CurrentVideo { get; set; }        

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public VideosViewModel(ISQLFundamentalsConfigManager configuration)
        {
            _configuration = configuration;
            VideoList = GetAllVideos();
            CurrentVideo = VideoList.FirstOrDefault();
        }

        public VideosViewModel(ISQLFundamentalsConfigManager configuration, int videoId)
        {
            _configuration = configuration;
            VideoList = new List<VideoModel>();

            if (videoId > 0)
            {
                CurrentVideo = GetVideo(videoId);
            }
            else
            {
                CurrentVideo = new VideoModel();
            }
        }

        public List<VideoModel> GetAllVideos()
        {
            return VideoController.GetAllVideos(_configuration);
        }

        public VideoModel GetVideo(int videoId)
        {
            return VideoController.GetVideoByID(videoId, _configuration);
        }
    }
}
