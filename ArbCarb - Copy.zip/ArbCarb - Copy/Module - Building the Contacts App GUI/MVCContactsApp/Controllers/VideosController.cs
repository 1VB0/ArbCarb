﻿using Microsoft.AspNetCore.Mvc;
using SQLFundamentals.DataAccess;
using SQLFundamentals.DataAccess.Controllers;

using MVCContactsApp.Models;


namespace MVCContactApp.Controllers
{                   //Update Delete
    public class VideosController:  Controller  //was Video""//
    {
        private readonly ISQLFundamentalsConfigManager _configuration;

        public VideosController(ISQLFundamentalsConfigManager configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            VideosViewModel model = new VideosViewModel(_configuration);
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(int videoID, string title, string description, string filePath)
        {
            if (videoID > 0)
            {
                VideoController.UpdateVideo(videoID, title, description, filePath, _configuration);
            }
            else
            {
                VideoController.CreateVideo( title, description, filePath, _configuration);
            }

            VideosViewModel model = new VideosViewModel(_configuration);
            model.IsActionSuccess = true;
            model.ActionMessage = "Video has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            VideosViewModel model = new VideosViewModel(_configuration, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            if (id > 0)
            {
                VideoController.DeleteVideo(id,_configuration);//
            }

            VideosViewModel model = new VideosViewModel(_configuration);
            model.IsActionSuccess = true;
            model.ActionMessage = "Video has been deleted successfully";
            return View("Index", model);
        }
    }
}
