﻿using SQLFundamentals.UI.CRUDConsole.Tools;

namespace SQLFundamentals.UI.CRUDConsole
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            new Demo().ChooseOption();
        }
    }
}

// tested create, update