﻿namespace SQLFundamentals.DataAccess.Models
{
    public class OrderModel
    {
    }
}