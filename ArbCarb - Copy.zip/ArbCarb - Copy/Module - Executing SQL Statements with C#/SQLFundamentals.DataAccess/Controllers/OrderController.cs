﻿namespace SQLFundamentals.DataAccess.Controllers
{
    public class OrderController
    {
    }
}