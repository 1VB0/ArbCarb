﻿using System;

namespace SQLFundamentals.UI.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
