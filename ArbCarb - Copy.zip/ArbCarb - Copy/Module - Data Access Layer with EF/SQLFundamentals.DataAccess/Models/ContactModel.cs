﻿namespace SQLFundamentals.DataAccess.Models
{
    public class ContactModel
    {
        public int ContactID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string EMailAddress { get; set; } = "";
    }
}